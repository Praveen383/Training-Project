import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userForm;
  openmodal: boolean;
  constructor(private router: Router) { }

  ngOnInit() {
    console.log(this.userForm)
  }

  /* for admin login */

  onUserFormSubmit(userForm) {
    console.log('form details', userForm.value.email);
    console.log('form details with reference', this.userForm);
    if (userForm.value.email === "p@gmail.com") {
      this.router.navigate(["/admin"]);
    } else if (userForm.value.email !== "p@gmail.com") {
      this.router.navigate(["/products"]);
    }
  }
}
