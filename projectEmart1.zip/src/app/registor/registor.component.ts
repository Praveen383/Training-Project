import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registor',
  templateUrl: './registor.component.html',
  styleUrls: ['./registor.component.css']
})
export class RegistorComponent implements OnInit {
  
  constructor(private router: Router) { }

  ngOnInit() {
  }
  onUserFormSubmit(data){
console.log('user detailes',data);
  //  this.router.navigate(['child','4'] , {queryParams : {name:'venki',age:'30'},fragment:'hi'} );

  }
}
